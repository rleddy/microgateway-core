codename=t$1.js

node $codename > dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
echo "====" >> dat$1.txt
node $codename >> dat$1.txt
#
node zdodat.js $1
